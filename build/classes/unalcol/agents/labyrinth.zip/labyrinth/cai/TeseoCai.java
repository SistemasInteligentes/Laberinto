package unalcol.agents.labyrinth.cai;

import unalcol.agents.simulate.util.SimpleLanguage;

public class TeseoCai extends SimpleTeseoAgentProgram {

    private Node treeMem = null;
    private Node lastNode = null;
    private int totalRotations = 0;
    protected SimpleLanguage lan;

    public TeseoCai() {
    }
    
    @Override
    public int accion(boolean PF, boolean PD, boolean PA, boolean PI, boolean MT) {

        if (MT) {
            return 4;
        } //en caso que al iniciar y tenga parades en las 3 direcciones rote 180 grados 
        else if (PF && PD && PI && totalRotations == 0) {
            return 2;
        }
        return callNextMovement(PF, PD, PA, PI, MT);
    }

    private int callNextMovement(boolean PF, boolean PD, boolean PA, boolean PI, boolean MT) {

        if (lastNode == null) {
            treeMem = new Node(null, totalRotations % 4, PF, PD, PA, PI, MT);
            lastNode = treeMem;
        } else {
            /*
             * revisa si ya exploro el camino, si no ha sido explorado 
             * crea los nodos hijos correspondientes; si ya fue explorado
             * no crea los nodos hijos, y continua adelante con una de las
             * posibilidades factibles.
             */
            if (hasGrandChild(lastNode) == 0) {
                /*
                 * revisa si esta en un callejon sin salida
                 * si lo esta elimina dicho nodo y da la orden para volver
                 */
                Node newNode = new Node(lastNode, totalRotations % 4, PF, PD, PA, PI, MT);
                if (!hasChildrens(newNode)) {
                    //ha encontrado un callejon sin salida
                    int aux = goReverse();
                    totalRotations += aux;
                    return aux;

                } //si se esta devolviendo no debe enlazar el nuevo nodo, en vez
                //debe seguir al siguiente nodo valido
                else if (!isGoingBack(newNode)) {
                    //enlace el nuevo nodo en su respectiva posicion
                    linkNode(newNode);
                }
            }
        }
        if (lastNode.getFront() != null) {
            /*
             * loopNode es el nodo donde comensaba el bucle detectado, 
             * la rama que generaba el bucle es eliminada por el 
             * metodo findLoop
             */
            Node loopNode;
            loopNode = treeMem.findLoop(lastNode.getFront());
            if (loopNode != null) {
                lastNode = loopNode;
                int aux = goReverse();
                totalRotations += aux;
                return aux;
            } else {

                lastNode = lastNode.getFront();
                int aux = getRotations(lastNode);
                totalRotations += aux;
                return aux;
            }
        } else if (lastNode.getRight() != null) {
            /*
             * loopNode es el nodo donde comensaba el bucle detectado, 
             * la rama que generaba el bucle es eliminada por el 
             * metodo findLoop
             */
            Node loopNode;
            loopNode = treeMem.findLoop(lastNode.getRight());
            if (loopNode != null) {
                lastNode = loopNode;
                int aux = goReverse();
                totalRotations += aux;
                return aux;
            } else {

                lastNode = lastNode.getRight();
                int aux = getRotations(lastNode);
                totalRotations += aux;
                return aux;
            }
        } else if (lastNode.getLeft() != null) {
            /*
             * loopNode es el nodo donde comensaba el bucle detectado, 
             * la rama que generaba el bucle es eliminada por el 
             * metodo findLoop
             */
            Node loopNode;
            loopNode = treeMem.findLoop(lastNode.getLeft());
            if (loopNode != null) {
                lastNode = loopNode;
                int aux = goReverse();
                totalRotations += aux;
                return aux;
            } else {

                lastNode = lastNode.getLeft();
                int aux = getRotations(lastNode);
                totalRotations += aux;
                return aux;
            }
        } else {
            int aux = goReverse();
            totalRotations += aux;
            return aux;
        }
        // return 4;//die
    }

    private int hasGrandChild(Node node) {
        int counter = 0;
        if (node.getFront() != null) {
            counter += hasGrandChild(node.getFront());
            return counter++;
        }
        if (node.getRight() != null) {

            counter += hasGrandChild(node.getRight());
            return counter++;
        }

        if (node.getLeft() != null) {

            counter += hasGrandChild(node.getLeft());
            return counter++;
        }
        return 0;
    }
    /*
     * revisa si un nodo dado tiene al menos un hijo
     */
    private Boolean hasChildrens(Node node) {
        if (node.getFront() != null) {
            return true;
        }
        if (node.getRight() != null) {
            return true;
        }
        if (node.getLeft() != null) {
            return true;
        }
        return false;
    }

    private int goReverse() {
        int xParent;
        int yParent;
        int x;
        int y;

        int action = 0;

        xParent = lastNode.getParent().getCoord_X();
        yParent = lastNode.getParent().getCoord_Y();
        x = lastNode.getCoord_X();
        y = lastNode.getCoord_Y();
        
        //segun donde se encuentre el bloqueo y hacia donde esta mirando toma 
        //la decision de cuantas rotaciones debe realizar
        if (x - xParent == 1) {
            //bloqueo a la derecha
            switch (totalRotations % 4) {
                case 0:
                    action = 3;
                    break;
                case 1:
                    action = 2;
                    break;
                case 2:
                    action = 1;
                    break;
                case 3:
                    action = 0;
                    break;
            }

        } else if (x - xParent == -1) {
            //bloqueo a la izquierda
            switch (totalRotations % 4) {
                case 0:
                    action = 1;
                    break;
                case 1:
                    action = 0;
                    break;
                case 2:
                    action = 3;
                    break;
                case 3:
                    action = 2;
                    break;
            }
        }
        if (y - yParent == 1) {
            //bloqueo arriba
            switch (totalRotations % 4) {
                case 0:
                    action = 2;
                    break;
                case 1:
                    action = 1;
                    break;
                case 2:
                    action = 0;
                    break;
                case 3:
                    action = 3;
                    break;
            }
        } else if (y - yParent == -1) {
            //bloqueo abajo
            switch (totalRotations % 4) {
                case 0:
                    action = 0;
                    break;
                case 1:
                    action = 3;
                    break;
                case 2:
                    action = 2;
                    break;
                case 3:
                    action = 1;
                    break;
            }
        }
        //eliminar ultimo nodo

        if (lastNode.getParent().getFront() != null && lastNode.getParent().getFront().equals(lastNode)) {
            lastNode = lastNode.getParent();
            lastNode.setFront(null);
        } else if (lastNode.getParent().getRight() != null && lastNode.getParent().getRight().equals(lastNode)) {
            lastNode = lastNode.getParent();
            lastNode.setRight(null);
        } else if (lastNode.getParent().getLeft() != null && lastNode.getParent().getLeft().equals(lastNode)) {
            lastNode = lastNode.getParent();
            lastNode.setLeft(null);

        }

        return action;
    }

    /*
     * Actualiza un nodo con sus hijos creados
     */
    private void linkNode(Node node) {
        if (lastNode.getParent().getFront() != null && lastNode.getParent().getFront().equals(lastNode)) {
            lastNode.getParent().setFront(node);
            lastNode = lastNode.getParent().getFront();
        } else if (lastNode.getParent().getRight() != null && lastNode.getParent().getRight().equals(lastNode)) {
            lastNode.getParent().setRight(node);
            lastNode = lastNode.getParent().getRight();
        } else if (lastNode.getParent().getLeft() != null && lastNode.getParent().getLeft().equals(lastNode)) {
            lastNode.getParent().setLeft(node);
            lastNode = lastNode.getParent().getLeft();
        }
    }

    private Boolean isGoingBack(Node node) {
        int x = lastNode.getParent().getCoord_X();
        int y = lastNode.getParent().getCoord_Y();
        if (node.getFront() != null && node.getFront().getCoord_X() == x && node.getFront().getCoord_Y() == y) {
            return true;
        } else if (node.getRight() != null && node.getRight().getCoord_X() == x && node.getRight().getCoord_Y() == y) {
            return true;
        } else if (node.getLeft() != null && node.getLeft().getCoord_X() == x && node.getLeft().getCoord_Y() == y) {
            return true;
        }
        return false;

    }

    private int getRotations(Node node) {

        int xParent;
        int yParent;
        int x;
        int y;

        int action = 0;

        xParent = node.getParent().getCoord_X();
        yParent = node.getParent().getCoord_Y();
        x = node.getCoord_X();
        y = node.getCoord_Y();

        //segun donde se encuentre la direccion de avance
        //retorna la decision de cuantas rotaciones debe realizar
        if (x - xParent == 1) {
            //movimiento a la derecha
            switch (totalRotations % 4) {
                case 0:
                    action = 1;
                    break;
                case 1:
                    action = 0;
                    break;
                case 2:
                    action = 3;
                    break;
                case 3:
                    action = 2;
                    break;
            }

        } else if (x - xParent == -1) {
            //movimiento a la izquierda
            switch (totalRotations % 4) {
                case 0:
                    action = 3;
                    break;
                case 1:
                    action = 2;
                    break;
                case 2:
                    action = 1;
                    break;
                case 3:
                    action = 0;
                    break;
            }
        }


        if (y - yParent == 1) {
            //movimiento arriba
            switch (totalRotations % 4) {
                case 0:
                    action = 0;
                    break;
                case 1:
                    action = 3;
                    break;
                case 2:
                    action = 2;
                    break;
                case 3:
                    action = 1;
                    break;
            }
        } else if (y - yParent == -1) {
            //bloqueo abajo
            switch (totalRotations % 4) {
                case 0:
                    action = 2;
                    break;
                case 1:
                    action = 1;
                    break;
                case 2:
                    action = 0;
                    break;
                case 3:
                    action = 3;
                    break;
            }
        }
        return action;



    }
}
